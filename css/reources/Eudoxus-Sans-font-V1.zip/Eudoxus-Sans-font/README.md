# Eudoxus Sans

This simple geometric font is named after the Greek mathematician Eudoxus of Cnidus. It is based on +Jakarta Sans by tokotype.
